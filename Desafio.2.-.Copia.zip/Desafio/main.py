import json
from pathlib import Path

import boto3
from botocore.exceptions import ClientError
from mypy_boto3_textract.type_defs import DetectDocumentTextResponseTypeDef


def detect_file_text(image_path: Path, output_path: Path) -> None:
    client = boto3.client("textract")

    with image_path.open("rb") as f:
        document_bytes = f.read()

    try:
        response = client.detect_document_text(Document={"Bytes": document_bytes})
        output_path.write_text(json.dumps(response, indent=2))
    except ClientError as e:
        print(f"Erro ao processar o documento: {e}")


def load_detected_text(response_path: Path) -> list[str]:
    try:
        data: DetectDocumentTextResponseTypeDef = json.loads(response_path.read_text())
        return [
            block["Text"]
            for block in data.get("Blocks", [])
            if block.get("BlockType") == "LINE"
        ]
    except FileNotFoundError:
        return []


def get_lines() -> list[str]:
    image_path = Path(__file__).parent / "images" / "lista-material-escolar.jpeg"
    response_path = Path("response.json")

    if not response_path.exists():
        detect_file_text(image_path, response_path)

    return load_detected_text(response_path)


if __name__ == "__main__":
    for line in get_lines():
        print(line)
