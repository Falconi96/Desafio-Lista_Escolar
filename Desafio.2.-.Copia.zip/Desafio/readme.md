# Projeto - Lista Escolar

## Arquivo: `readme.md`

Este arquivo contém uma breve documentação sobre o processo de desenvolvimento realizado durante o conteúdo estudado.

---

## Resumo do Processo

Durante o desenvolvimento deste projeto, segui os seguintes passos principais:

1. **Leitura e compreensão do conteúdo proposto**
2. **Aplicação prática dos conceitos abordados**
3. **Testes, ajustes e correções**
4. **Documentação e reflexão sobre o aprendizado**

---

## **Prints do Processo**

### Etapa 1 - Início do Projeto
![Print do início do projeto](./Imagem/Inicio_desafio.png)

---

### Etapa 2 - response.json

![Print do response.json](./Imagem/response.json.png)

Durante a utilização do AWS Textract, enfrentei alguns desafios. 
Um deles foi entender como extrair corretamente as informações dos blocos de texto retornados, já 
que a estrutura do JSON exige bastante atenção para identificar o que realmente importa. Também tive 
certa dificuldade em lidar com os relacionamentos entre os blocos (como LINE, WORD e suas 
hierarquias), o que exigiu tempo para testes e ajustes no código. Apesar disso, foi uma experiência 
de aprendizado valiosa, que me ajudou a compreender melhor como funciona o processamento inteligente 
de documentos na AWS.


